def word_count(str):
    counts=dict()
    words=str.split()
    for words in words:
        if word in counts:
            counts[word]+=1
        else:
            counts[word]= 1
            return counts
        print(word_count("The girl sing a beautiful song."))
