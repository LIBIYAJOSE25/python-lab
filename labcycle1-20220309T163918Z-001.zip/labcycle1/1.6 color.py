color1=["red","Green","yellow"]
color2=["white","black"]
print("color list is")
print(color1)
print(color2)
for element in color1:
    if element not in color2:
        print(element)