dict1={1:'apple',2:'orange'}
dict2={3:'mango',4:'banana'}
dict2.update(dict1)
print(dict2)