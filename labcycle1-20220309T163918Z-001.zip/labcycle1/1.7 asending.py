y = {'apple': 1, 'orange': 10, 'banana': 30, 'mango': 2}
l = list(y.items())
dict = dict(l)
print("Dictionary", dict)
l.sort()
print('Ascending order is', l)
l = list(y.items())
l.sort(reverse=True)
print('Descending order is', l)