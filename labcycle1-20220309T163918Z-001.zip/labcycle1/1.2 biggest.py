
a=int(input("Entre first number:"))
b=int(input("Entre second number:"))
c=int(input("Entre third number:"))
if (a>b) and (a>c):
    Biggest_num=a
elif(b>a) and (b>c):
    Biggest_num=b
else:
    Biggest_num=c
    printf("The Biggest number=",Biggest_num)