print("Enter current year:")
currentyear=int(input())
print("Enter the final year:")
finalyear=int(input())
print("list of leap years:")
for year in range(currentyear,finalyear):
    if(0==year%4) and (0!=year%100) or (0==year%100):
        print(year)