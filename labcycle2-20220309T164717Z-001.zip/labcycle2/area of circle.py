pi=3.14
radius=float(input("enter the radius of circle:"))
area=pi*radius*radius
print("Area of circle=%2f"%area)