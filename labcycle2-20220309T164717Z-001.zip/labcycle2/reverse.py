numlist = []
number = int(input("enter the total number of list elements:"))
for i in range(1, number + 1):
    value = int(input("enter the value of %d element" % i))
    numlist.append(value)
    numlist.reverse()
    print("\n the result of a reverse list=", numlist)
