x=["Libiya"]
value=[ord(x)for x in x for x in x]
print(value)