list=[1,2,3,-4,-5,-6]
for x in list:
    if x>0:
        print(x)

