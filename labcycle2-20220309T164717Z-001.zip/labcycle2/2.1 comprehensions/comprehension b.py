
numbers=[1,2,3,4,5]
squred_numbers=[number ** 2 for number in numbers]
print(squred_numbers)