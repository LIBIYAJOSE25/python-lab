words=['apple','orange','pear','milk','snake','tiger','eagle']
for word in words:
    if word[0] in "aeiou":
        print(word)