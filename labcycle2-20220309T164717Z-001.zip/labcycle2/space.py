str1=str(input("enter the first string:"))
str2=str(input("enter the second string:"))
print("Before swapping:",str1+" "+str2)
a=str1[0]
a1=str1[1:]
b=str2[0]
b1=str2[1:]
print("After swapping:",b+a1+" "+a+b1)