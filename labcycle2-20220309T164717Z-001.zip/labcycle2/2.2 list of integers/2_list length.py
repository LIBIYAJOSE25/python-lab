list1=[1,2,3,4]
list2=[3,4,5]
print("list of 2 integers are:")
print("list1",list1)
print("list2",list2)
a=len(list1)
b=len(list2)
if a==b:
    print("length of 'list' and 'list2' are same:",a,b)
else:
    print("length is not same in 'list1' and 'list2'",a,b)
