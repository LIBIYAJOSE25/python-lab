import math
list1=[2,3,4]
list2=[1,3,5]
if(sum(list1)==sum(list2)):
    print("sum of list1 and list2",sum(list1),sum(list2))
else:
    print("sum is not equal")