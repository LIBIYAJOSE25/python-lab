p=int(input("Enter the principal amount:"))
r=int(input("Enter the rate of interest:"))
t=int(input("Enter the time in the years:"))

ci=p*(pow((1+r/100),t))

print("principal amount:",p)
print("interest rate:",r)
print("time in years:",t)
print("compount interest",ci)