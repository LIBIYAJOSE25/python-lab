num=int(input("enter a number:"))
def fact(x):
    fact=1
    for i in range(x,0,-1):
        print("factorial=",fact)
        fact(num)
