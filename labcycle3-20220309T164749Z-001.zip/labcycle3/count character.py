string="libiya"
count=0;
for i in range(0,len(string)):
    if(string[i]!=''):
        count=count+1;
        print("total number of characters in a string:"+str(count))