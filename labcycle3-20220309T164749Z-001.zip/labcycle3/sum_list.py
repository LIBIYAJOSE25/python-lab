list=[5,11,24,18,2]
total=sum(list)
print("sum of all elements in given list:",total)